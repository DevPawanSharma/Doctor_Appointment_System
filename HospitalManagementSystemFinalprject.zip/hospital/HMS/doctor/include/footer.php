<footer>
				<div class="footer-inner">
					<div class="pull-left" align="center">
						&copy; <span class="current-year"></span><span class="text-bold text-uppercase"> Doctor Appointment System</span>. <span>All rights reserved</span>
					</div>
					<div class="pull-right">
						<span class="go-top"><i class="ti-angle-up"></i></span>
					</div>
				</div>
			</footer>